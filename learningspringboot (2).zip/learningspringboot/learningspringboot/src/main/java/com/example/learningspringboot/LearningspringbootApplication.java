package com.example.learningspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningspringbootApplication {

	public static void main(String[] args) {
		System.out.println("Hello World");

		SpringApplication.run(LearningspringbootApplication.class, args);
	}

}
