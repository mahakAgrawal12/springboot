package com.example.learningspringboot.Controller;

import com.example.learningspringboot.Service.PaymentService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.learningspringboot.DTO.PaymentRequest;
import com.example.learningspringboot.DTO.PaymentResponse;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
     PaymentService paymentService;
    @GetMapping("/{id}")


    public ResponseEntity<PaymentResponse> getPaymentById(@PathVariable Long id)
    {
        //map incoming data to internal request DTO
        PaymentRequest internalRequestObj = new PaymentRequest();
        internalRequestObj.setPaymentId(id);

        //pass this internalRequestObj to furthur layer for processing
        PaymentResponse payment = paymentService.getPaymentDetailsById(internalRequestObj);

        //return to Response DTO
        return ResponseEntity.ok(payment);
    }
}
